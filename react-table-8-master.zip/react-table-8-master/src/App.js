import "./App.css";
import BasicTable from "./componets/basic-table";

function App() {
  return (
    <>
      <BasicTable />
    </>
  );
}

export default App;
